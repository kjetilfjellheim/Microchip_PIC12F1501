/**
 * Initaliztion of the registers.
 */
void InitApp(void);        
/**
 * 
 * @return 
 */
unsigned int getMeasurement();
/**
 * 
 * @param value
 * @return 
 */
int calculateTemperature(int value);